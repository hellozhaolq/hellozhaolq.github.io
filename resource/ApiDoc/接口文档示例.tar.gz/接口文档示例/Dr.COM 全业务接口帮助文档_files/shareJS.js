
//表格文本过滤
$(function () {
    'use strict';
    var tableFilter = function () {
        var timeout = null;
        var _target, _context;

        function _inner() {
            var rows = $(_target).find("tbody > tr").show();
            if (_context != null && _context.length > 0) {
                rows.hide().filter(":contains('" + _context + "')").show();
            }
        }

        return function (target, context, delay) {
            _target = target;
            _context = context;
            window.clearTimeout(timeout);
            timeout = window.setTimeout(_inner, delay || 300);
        };
    }();

    $('[data-toggle="table-search"]').keyup(function () {
        var $filter = $(this).parents('div.sub_content');
        var target = $filter.data("target");
        var context = $filter.find('[data-toggle="table-search"]').val();
        tableFilter(target, context, 300);
    });

});

/**
 * 取当前url
 * 返回格式 http://127.0.0.1:8080/Drcom
 * @return {TypeName} 
 */
var HostPath = {
	curPath : window.location.href, //http://127.0.0.1:8080
	pathName : window.location.pathname, 
	curURL : function () {
		var path = [];
			path.push(this.curPath.substring(0,this.curPath.indexOf(this.pathName)));
			path.push(this.pathName.substring(0,this.pathName.substr(1).indexOf('/')+1));
			path.push('/');
		return path.join('');
	}
};

