
$(function () {
	'use strict';
	
//	var url = window.location.href;
//	var ind = url.indexOf("#");
//	if (ind > -1) {
//		var hrefid = url.substring(ind);
//		window.location.href = url.substring(0, ind+1);
//	}
	
});