@echo off
echo ---------------------- blade-charge start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-charge > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-charge closed successfully
)
echo Preparing to run the blade-charge program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo blade-charge is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./blade-charge.jar --server.port=61061

del %pidPath%
echo ---------------------- blade-charge start end ----------------------