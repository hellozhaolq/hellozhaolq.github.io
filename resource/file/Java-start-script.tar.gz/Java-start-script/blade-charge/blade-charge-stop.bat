@echo off
echo ---------------------- blade-charge stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-charge > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-charge closed successfully
) else (
    echo blade-charge is not running
)

del %pidPath%
echo ---------------------- blade-charge stop begin ----------------------