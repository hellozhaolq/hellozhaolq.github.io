PID=$(ps -ef | grep blade-charge.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-charge is running
else
  echo kill $PID
  kill $PID
  echo blade-charge is already stopped
  echo blade-charge is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=61061 -jar blade-charge.jar >/dev/null 2>blade-charge-error-61061.log &
