PID=$(ps -ef | grep blade-charge.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-charge is already stopped
else
  echo kill $PID
  kill $PID
fi

