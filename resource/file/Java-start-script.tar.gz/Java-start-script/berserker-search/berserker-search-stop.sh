PID=$(ps -ef | grep berserker-search.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-search is already stopped
else
  echo kill $PID
  kill $PID
fi

