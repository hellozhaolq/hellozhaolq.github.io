PID=$(ps -ef | grep berserker-search.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-search is running
else
  echo kill $PID
  kill $PID
  echo berserker-search is already stopped
  echo berserker-search is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60141 -jar berserker-search.jar >/dev/null 2>berserker-search-error-60141.log &
