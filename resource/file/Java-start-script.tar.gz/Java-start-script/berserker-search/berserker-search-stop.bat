@echo off
echo ---------------------- berserker-search stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-search > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-search closed successfully
) else (
    echo berserker-search is not running
)

del %pidPath%
echo ---------------------- berserker-search stop begin ----------------------