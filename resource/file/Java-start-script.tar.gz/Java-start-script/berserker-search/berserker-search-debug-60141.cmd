@echo off
rem set JAVA_HOME=G:\syntong\jdk1.8.0_112
rem set PATH=%JAVA_HOME%\bin;
java -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-search.jar --server.port=60141
pause