PID=$(ps -ef | grep blade-manage.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-manage is running
else
  echo kill $PID
  kill $PID
  echo blade-manage is already stopped
  echo blade-manage is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=61041 -jar blade-manage.jar >/dev/null 2>blade-manage-error-61041.log &
