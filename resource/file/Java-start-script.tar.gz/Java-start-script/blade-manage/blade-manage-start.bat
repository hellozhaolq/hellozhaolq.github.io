@echo off
echo ---------------------- blade-manage start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-manage > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-manage closed successfully
)
echo Preparing to run the blade-manage program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo blade-manage is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./blade-manage.jar --server.port=61041

del %pidPath%
echo ---------------------- blade-manage start end ----------------------