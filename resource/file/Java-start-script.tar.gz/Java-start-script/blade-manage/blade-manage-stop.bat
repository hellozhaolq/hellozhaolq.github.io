@echo off
echo ---------------------- blade-manage stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-manage > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-manage closed successfully
) else (
    echo blade-manage is not running
)

del %pidPath%
echo ---------------------- blade-manage stop begin ----------------------