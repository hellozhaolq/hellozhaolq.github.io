PID=$(ps -ef | grep blade-manage.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-manage is already stopped
else
  echo kill $PID
  kill $PID
fi

