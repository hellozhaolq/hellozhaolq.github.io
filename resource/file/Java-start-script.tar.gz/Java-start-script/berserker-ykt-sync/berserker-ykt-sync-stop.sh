PID=$(ps -ef | grep berserker-ykt-sync.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-ykt-sync is already stopped
else
  echo kill $PID
  kill $PID
fi

