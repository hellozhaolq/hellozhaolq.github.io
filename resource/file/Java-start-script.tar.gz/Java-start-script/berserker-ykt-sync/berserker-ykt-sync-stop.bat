@echo off
echo ---------------------- berserker-ykt-sync stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-ykt-sync > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-ykt-sync closed successfully
) else (
    echo berserker-ykt-sync is not running
)

del %pidPath%
echo ---------------------- berserker-ykt-sync stop begin ----------------------