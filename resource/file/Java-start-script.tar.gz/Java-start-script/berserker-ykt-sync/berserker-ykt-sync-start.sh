PID=$(ps -ef | grep berserker-ykt-sync.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-ykt-sync is running
else
  echo kill $PID
  kill $PID
  echo berserker-ykt-sync is already stopped
  echo berserker-ykt-sync is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60241 -jar berserker-ykt-sync.jar >/dev/null 2>berserker-ykt-sync-error-60121.log &
