@echo off

set rootPath=%CD%

echo.
echo;
cd %rootPath%\berserker-gateway
call berserker-gateway-stop.bat

echo.
echo;
cd %rootPath%\berserker-auth
call berserker-auth-stop.bat

echo.
echo;
cd %rootPath%\berserker-base
call berserker-base-stop.bat

echo.
echo;
cd %rootPath%\berserker-app
call berserker-app-stop.bat

echo.
echo;
cd %rootPath%\berserker-advertising
call berserker-advertising-stop.bat

echo.
echo;
cd %rootPath%\berserker-ykt
call berserker-ykt-stop.bat

echo.
echo;
cd %rootPath%\berserker-ykt-sync
call berserker-ykt-sync-stop.bat

echo.
echo;
cd %rootPath%\berserker-ykt-turnover
call berserker-ykt-turnover-stop.bat

echo.
echo;
cd %rootPath%\berserker-search
call berserker-search-stop.bat

echo.
echo;
cd %rootPath%\berserker-secure
call berserker-secure-stop.bat

echo.
echo;
cd %rootPath%\berserker-schedule
call berserker-schedule-stop.bat

echo.
echo;
cd %rootPath%\berserker-log
call berserker-log-stop.bat

echo.
echo;
cd %rootPath%\berserker-message
call berserker-message-stop.bat





echo.
echo;
cd %rootPath%\blade-gateway
call blade-gateway-stop.bat

echo.
echo;
cd %rootPath%\blade-auth
call blade-auth-stop.bat

echo.
echo;
cd %rootPath%\blade-manage
call blade-manage-stop.bat

echo.
echo;
cd %rootPath%\blade-charge
call blade-charge-stop.bat

echo.
echo;
cd %rootPath%\blade-pay
call blade-pay-stop.bat
































echo.
echo;

echo The window will close after 3 seconds...
choice /t 3 /d y /n >nul

rem 跳过旧版stop，否则它会stop掉本机所有的java项目
goto ignore
set pidFile=pid
set pidPath=%CD%\%pidFile%
tasklist | findstr java > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% equ 0 (
    echo java program is not running
) else (
    for /f "tokens=2" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo all java program closed successfully
)

del %pidPath%
:ignore


rem echo 按任意键退出 && pause>nul
rem echo.
rem echo,
rem echo;