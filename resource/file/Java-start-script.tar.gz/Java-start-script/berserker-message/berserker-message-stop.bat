@echo off
echo ---------------------- berserker-message stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-message > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-message closed successfully
) else (
    echo berserker-message is not running
)

del %pidPath%
echo ---------------------- berserker-message stop begin ----------------------