PID=$(ps -ef | grep berserker-message.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-message is running
else
  echo kill $PID
  kill $PID
  echo berserker-message is already stopped
  echo berserker-message is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60221 -jar berserker-message.jar >/dev/null 2>berserker-message-error-60221.log &