PID=$(ps -ef | grep berserker-message.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-message is already stopped
else
  echo kill $PID
  kill $PID
fi

