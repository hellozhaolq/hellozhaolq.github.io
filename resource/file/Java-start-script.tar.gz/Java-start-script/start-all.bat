@echo off

set rootPath=%CD%

echo.
echo;
cd %rootPath%\berserker-gateway
call berserker-gateway-start.bat

echo.
echo;
cd %rootPath%\berserker-auth
call berserker-auth-start.bat

echo.
echo;
cd %rootPath%\berserker-base
call berserker-base-start.bat

echo.
echo;
cd %rootPath%\berserker-app
call berserker-app-start.bat

echo.
echo;
cd %rootPath%\berserker-advertising
call berserker-advertising-start.bat

echo.
echo;
cd %rootPath%\berserker-ykt
call berserker-ykt-start.bat

echo.
echo;
cd %rootPath%\berserker-ykt-sync
call berserker-ykt-sync-start.bat

echo.
echo;
cd %rootPath%\berserker-ykt-turnover
call berserker-ykt-turnover-start.bat

echo.
echo;
cd %rootPath%\berserker-search
call berserker-search-start.bat

echo.
echo;
cd %rootPath%\berserker-secure
call berserker-secure-start.bat

echo.
echo;
cd %rootPath%\berserker-schedule
call berserker-schedule-start.bat

echo.
echo;
cd %rootPath%\berserker-log
call berserker-log-start.bat

echo.
echo;
cd %rootPath%\berserker-message
call berserker-message-start.bat





echo.
echo;
cd %rootPath%\blade-gateway
call blade-gateway-start.bat

echo.
echo;
cd %rootPath%\blade-auth
call blade-auth-start.bat

echo.
echo;
cd %rootPath%\blade-manage
call blade-manage-start.bat

echo.
echo;
cd %rootPath%\blade-charge
call blade-charge-start.bat

echo.
echo;
cd %rootPath%\blade-pay
call blade-pay-start.bat







echo.
echo;

echo The window will close after 3 seconds...
choice /t 3 /d y /n >nul
rem echo 按任意键退出 && pause>nul
rem echo.
rem echo,
rem echo;