@echo off
echo ---------------------- berserker-advertising stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-advertising > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-advertising closed successfully
) else (
    echo berserker-advertising is not running
)

del %pidPath%
echo ---------------------- berserker-advertising stop begin ----------------------