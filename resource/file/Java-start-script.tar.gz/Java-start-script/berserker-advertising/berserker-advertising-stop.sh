PID=$(ps -ef | grep berserker-advertising.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-advertising is already stopped
else
  echo kill $PID
  kill $PID
fi

