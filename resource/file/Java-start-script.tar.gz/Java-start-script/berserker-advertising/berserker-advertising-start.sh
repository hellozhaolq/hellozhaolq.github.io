PID=$(ps -ef | grep berserker-advertising.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-advertising is running
else
  echo kill $PID
  kill $PID
  echo berserker-advertising is already stopped
  echo berserker-advertising is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60081 -jar berserker-advertising.jar >/dev/null 2>berserker-advertising-error-60081.log &
