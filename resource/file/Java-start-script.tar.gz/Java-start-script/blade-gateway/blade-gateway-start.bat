@echo off
echo ---------------------- blade-gateway start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-gateway > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-gateway closed successfully
)
echo Preparing to run the blade-gateway program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo blade-gateway is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./blade-gateway.jar --server.port=61001

del %pidPath%
echo ---------------------- blade-gateway start end ----------------------