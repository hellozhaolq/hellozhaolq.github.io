PID=$(ps -ef | grep blade-gateway.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-gateway is already stopped
else
  echo kill $PID
  kill $PID
fi

