PID=$(ps -ef | grep blade-gateway.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-gateway is running
else
  echo kill $PID
  kill $PID
  echo blade-gateway is already stopped
  echo blade-gateway is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=61001 -jar blade-gateway.jar >/dev/null 2>blade-gateway-error-61001.log &
