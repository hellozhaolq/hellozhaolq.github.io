@echo off
echo ---------------------- blade-gateway stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-gateway > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-gateway closed successfully
) else (
    echo blade-gateway is not running
)

del %pidPath%
echo ---------------------- blade-gateway stop begin ----------------------