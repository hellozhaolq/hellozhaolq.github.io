@echo off
echo ---------------------- blade-auth stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-auth > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-auth closed successfully
) else (
    echo blade-auth is not running
)

del %pidPath%
echo ---------------------- blade-auth stop begin ----------------------