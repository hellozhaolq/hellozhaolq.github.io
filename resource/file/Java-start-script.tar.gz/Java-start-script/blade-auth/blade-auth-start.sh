PID=$(ps -ef | grep blade-auth.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-auth is running
else
  echo kill $PID
  kill $PID
  echo blade-auth is already stopped
  echo blade-auth is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=61021 -jar blade-auth.jar >/dev/null 2>blade-auth-error-61021.log &
