@echo off
echo ---------------------- blade-auth start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-auth > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-auth closed successfully
)
echo Preparing to run the blade-auth program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo blade-auth is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./blade-auth.jar --server.port=61021

del %pidPath%
echo ---------------------- blade-auth start end ----------------------