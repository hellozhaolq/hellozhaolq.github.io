PID=$(ps -ef | grep blade-auth.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-auth is already stopped
else
  echo kill $PID
  kill $PID
fi

