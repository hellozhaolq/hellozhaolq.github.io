PORT=$(netstat -tnlp | grep java | awk '{print $4}' | sort -n)
echo $PORT

