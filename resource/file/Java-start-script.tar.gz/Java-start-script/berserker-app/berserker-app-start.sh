PID=$(ps -ef | grep berserker-app.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-app is running
else
  echo kill $PID
  kill $PID
  echo berserker-app is already stopped
  echo berserker-app is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60061 -jar berserker-app.jar >/dev/null 2>berserker-app-error-60061.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60062 -jar berserker-app.jar >/dev/null 2>berserker-app-error-60062.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60063 -jar berserker-app.jar >/dev/null 2>berserker-app-error-60063.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60064 -jar berserker-app.jar >/dev/null 2>berserker-app-error-60064.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60065 -jar berserker-app.jar >/dev/null 2>berserker-app-error-60065.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60066 -jar berserker-app.jar >/dev/null 2>berserker-app-error-60066.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60067 -jar berserker-app.jar >/dev/null 2>berserker-app-error-60067.log &