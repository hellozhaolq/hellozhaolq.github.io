@echo off
echo ---------------------- berserker-app stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-app > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-app closed successfully
) else (
    echo berserker-app is not running
)

del %pidPath%
echo ---------------------- berserker-app stop begin ----------------------