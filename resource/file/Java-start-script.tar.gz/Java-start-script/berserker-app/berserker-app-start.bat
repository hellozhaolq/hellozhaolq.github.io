@echo off
echo ---------------------- berserker-app start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-app > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-app closed successfully
)
echo Preparing to run the berserker-app program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo berserker-app is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-app.jar --server.port=60061
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-app.jar --server.port=60062
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-app.jar --server.port=60063
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-app.jar --server.port=60064
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-app.jar --server.port=60065
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-app.jar --server.port=60066
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-app.jar --server.port=60067

del %pidPath%
echo ---------------------- berserker-app start end ----------------------