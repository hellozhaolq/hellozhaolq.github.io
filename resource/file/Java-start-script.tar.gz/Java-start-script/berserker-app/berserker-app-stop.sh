PID=$(ps -ef | grep berserker-app.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-app is already stopped
else
  echo kill $PID
  kill $PID
fi

