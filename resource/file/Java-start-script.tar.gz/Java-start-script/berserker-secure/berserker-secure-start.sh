PID=$(ps -ef | grep berserker-secure.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-secure is running
else
  echo kill $PID
  kill $PID
  echo berserker-secure is already stopped
  echo berserker-secure is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60161 -jar berserker-secure.jar >/dev/null 2>berserker-secure-error-60161.log &
