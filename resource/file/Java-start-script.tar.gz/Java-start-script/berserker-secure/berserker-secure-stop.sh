PID=$(ps -ef | grep berserker-secure.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-secure is already stopped
else
  echo kill $PID
  kill $PID
fi

