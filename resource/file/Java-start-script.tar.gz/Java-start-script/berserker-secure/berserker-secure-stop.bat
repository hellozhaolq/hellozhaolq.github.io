@echo off
echo ---------------------- berserker-secure stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-secure > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-secure closed successfully
) else (
    echo berserker-secure is not running
)

del %pidPath%
echo ---------------------- berserker-secure stop begin ----------------------