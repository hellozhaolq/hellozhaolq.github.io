PID=$(ps -ef | grep berserker-ykt-turnover.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-ykt-turnover is running
else
  echo kill $PID
  kill $PID
  echo berserker-ykt-turnover is already stopped
  echo berserker-ykt-turnover is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60121 -jar berserker-ykt-turnover.jar >/dev/null 2>berserker-ykt-turnover-error-60121.log &
