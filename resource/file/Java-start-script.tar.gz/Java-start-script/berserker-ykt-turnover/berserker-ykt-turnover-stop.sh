PID=$(ps -ef | grep berserker-ykt-turnover.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-ykt-turnover is already stopped
else
  echo kill $PID
  kill $PID
fi

