@echo off
echo ---------------------- berserker-ykt-turnover stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-ykt-turnover > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-ykt-turnover closed successfully
) else (
    echo berserker-ykt-turnover is not running
)

del %pidPath%
echo ---------------------- berserker-ykt-turnover stop begin ----------------------