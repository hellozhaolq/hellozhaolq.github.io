@echo off
echo ---------------------- berserker-ykt-turnover start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-ykt-turnover > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-ykt-turnover closed successfully
)
echo Preparing to run the berserker-ykt-turnover program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo berserker-ykt-turnover is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-ykt-turnover.jar --server.port=60121

del %pidPath%
echo ---------------------- berserker-ykt-turnover start end ----------------------