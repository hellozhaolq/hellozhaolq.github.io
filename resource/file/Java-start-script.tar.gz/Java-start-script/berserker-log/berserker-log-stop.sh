PID=$(ps -ef | grep berserker-log.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-log is already stopped
else
  echo kill $PID
  kill $PID
fi

