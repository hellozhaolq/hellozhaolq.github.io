@echo off
echo ---------------------- berserker-log start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-log > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-log closed successfully
)
echo Preparing to run the berserker-log program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo berserker-log is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-log.jar --server.port=60201

del %pidPath%
echo ---------------------- berserker-log start end ----------------------