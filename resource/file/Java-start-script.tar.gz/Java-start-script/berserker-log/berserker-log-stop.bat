@echo off
echo ---------------------- berserker-log stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-log > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-log closed successfully
) else (
    echo berserker-log is not running
)

del %pidPath%
echo ---------------------- berserker-log stop begin ----------------------