PID=$(ps -ef | grep berserker-log.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-log is running
else
  echo kill $PID
  kill $PID
  echo berserker-log is already stopped
  echo berserker-log is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60201 -jar berserker-log.jar >/dev/null 2>berserker-log-error-60201.log &
