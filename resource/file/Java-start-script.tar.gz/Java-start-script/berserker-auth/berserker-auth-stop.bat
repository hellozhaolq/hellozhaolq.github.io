@echo off
echo ---------------------- berserker-auth stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-auth > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-auth closed successfully
) else (
    echo berserker-auth is not running
)

del %pidPath%
echo ---------------------- berserker-auth stop begin ----------------------