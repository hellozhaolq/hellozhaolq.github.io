PID=$(ps -ef | grep berserker-auth.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-auth is already stopped
else
  echo kill $PID
  kill $PID
fi

