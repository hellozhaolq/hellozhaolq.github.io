PID=$(ps -ef | grep berserker-auth.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-auth is running
else
  echo kill $PID
  kill $PID
  echo berserker-auth is already stopped
  echo berserker-auth is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60021 -jar berserker-auth.jar >/dev/null 2>berserker-auth-error-60021.log &
