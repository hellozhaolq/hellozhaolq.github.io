@echo off
echo ---------------------- berserker-auth start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-auth > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-auth closed successfully
)
echo Preparing to run the berserker-auth program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo berserker-auth is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-auth.jar --server.port=60021

del %pidPath%
echo ---------------------- berserker-auth start end ----------------------