@echo off
echo ---------------------- berserker-ykt start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-ykt > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-ykt closed successfully
)
echo Preparing to run the berserker-ykt program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo berserker-ykt is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-ykt.jar --server.port=60101

del %pidPath%
echo ---------------------- berserker-ykt start end ----------------------