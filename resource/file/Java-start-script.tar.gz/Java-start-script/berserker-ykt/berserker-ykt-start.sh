PID=$(ps -ef | grep berserker-ykt.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-ykt is running
else
  echo kill $PID
  kill $PID
  echo berserker-ykt is already stopped
  echo berserker-ykt is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60101 -jar berserker-ykt.jar >/dev/null 2>berserker-ykt-error-60101.log &
