PID=$(ps -ef | grep blade-pay.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-pay is running
else
  echo kill $PID
  kill $PID
  echo blade-pay is already stopped
  echo blade-pay is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=61081 -jar blade-pay.jar >/dev/null 2>blade-pay-error-61081.log &
