@echo off
echo ---------------------- blade-pay stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-pay > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-pay closed successfully
) else (
    echo blade-pay is not running
)

del %pidPath%
echo ---------------------- blade-pay stop begin ----------------------