PID=$(ps -ef | grep blade-pay.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo blade-pay is already stopped
else
  echo kill $PID
  kill $PID
fi

