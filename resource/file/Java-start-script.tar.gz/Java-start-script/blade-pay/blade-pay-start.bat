@echo off
echo ---------------------- blade-pay start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr blade-pay > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo blade-pay closed successfully
)
echo Preparing to run the blade-pay program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo blade-pay is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./blade-pay.jar --server.port=61081

del %pidPath%
echo ---------------------- blade-pay start end ----------------------