PID=$(ps -ef | grep berserker-gateway.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-gateway is already stopped
else
  echo kill $PID
  kill $PID
fi

