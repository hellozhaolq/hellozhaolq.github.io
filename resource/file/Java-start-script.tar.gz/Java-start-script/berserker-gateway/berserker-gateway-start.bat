@echo off
echo ---------------------- berserker-gateway start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-gateway > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-gateway closed successfully
)
echo Preparing to run the berserker-gateway program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo berserker-gateway is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-gateway.jar --server.port=60001
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-gateway.jar --server.port=60002
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-gateway.jar --server.port=60003
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-gateway.jar --server.port=60004
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-gateway.jar --server.port=60005
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-gateway.jar --server.port=60006

del %pidPath%
echo ---------------------- berserker-gateway start end ----------------------