@echo off
echo ---------------------- berserker-gateway stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-gateway > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-gateway closed successfully
) else (
    echo berserker-gateway is not running
)

del %pidPath%
echo ---------------------- berserker-gateway stop begin ----------------------