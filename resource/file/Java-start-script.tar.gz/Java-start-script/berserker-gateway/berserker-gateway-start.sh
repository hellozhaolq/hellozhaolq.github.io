PID=$(ps -ef | grep berserker-gateway.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-gateway is running
else
  echo kill $PID
  kill $PID
  echo berserker-gateway is already stopped
  echo berserker-gateway is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60001 -jar berserker-gateway.jar >/dev/null 2>berserker-gateway-error-60001.log &

nohup java -Dfile.encoding=UTF-8 -Dserver.port=60002 -jar berserker-gateway.jar >/dev/null 2>berserker-gateway-error-60002.log &

nohup java -Dfile.encoding=UTF-8 -Dserver.port=60003 -jar berserker-gateway.jar >/dev/null 2>berserker-gateway-error-60003.log &

nohup java -Dfile.encoding=UTF-8 -Dserver.port=60004 -jar berserker-gateway.jar >/dev/null 2>berserker-gateway-error-60004.log &

nohup java -Dfile.encoding=UTF-8 -Dserver.port=60005 -jar berserker-gateway.jar >/dev/null 2>berserker-gateway-error-60005.log &

nohup java -Dfile.encoding=UTF-8 -Dserver.port=60006 -jar berserker-gateway.jar >/dev/null 2>berserker-gateway-error-60006.log &

