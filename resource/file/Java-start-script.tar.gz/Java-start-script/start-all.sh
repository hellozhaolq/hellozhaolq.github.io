pwd=$PWD

cd $pwd/berserker-gateway
chmod +x ./berserker-gateway-start.sh
source ./berserker-gateway-start.sh

cd $pwd/berserker-auth
chmod +x ./berserker-auth-start.sh
source ./berserker-auth-start.sh

cd $pwd/berserker-base
chmod +x ./berserker-base-start.sh
source ./berserker-base-start.sh

cd $pwd/berserker-app
chmod +x ./berserker-app-start.sh
source ./berserker-app-start.sh

cd $pwd/berserker-advertising
chmod +x ./berserker-advertising-start.sh
source ./berserker-advertising-start.sh

cd $pwd/berserker-ykt
chmod +x ./berserker-ykt-start.sh
source ./berserker-ykt-start.sh

cd $pwd/berserker-ykt-sync
chmod +x ./berserker-ykt-sync-start.sh
source ./berserker-ykt-sync-start.sh

cd $pwd/berserker-ykt-turnover
chmod +x ./berserker-ykt-turnover-start.sh
source ./berserker-ykt-turnover-start.sh

cd $pwd/berserker-search
chmod +x ./berserker-search-start.sh
source ./berserker-search-start.sh

cd $pwd/berserker-secure
chmod +x ./berserker-secure-start.sh
source ./berserker-secure-start.sh

cd $pwd/berserker-schedule
chmod +x ./berserker-schedule-start.sh
source ./berserker-schedule-start.sh

cd $pwd/berserker-log
chmod +x ./berserker-log-start.sh
source ./berserker-log-start.sh

cd $pwd/berserker-message
chmod +x ./berserker-message-start.sh
source ./berserker-message-start.sh





cd $pwd/blade-gateway
chmod +x ./blade-gateway-start.sh
source ./blade-gateway-start.sh

cd $pwd/blade-auth
chmod +x ./blade-auth-start.sh
source ./blade-auth-start.sh

cd $pwd/blade-manage
chmod +x ./blade-manage-start.sh
source ./blade-manage-start.sh

cd $pwd/blade-charge
chmod +x ./blade-charge-start.sh
source ./blade-charge-start.sh

cd $pwd/blade-pay
chmod +x ./blade-pay-start.sh
source ./blade-pay-start.sh







