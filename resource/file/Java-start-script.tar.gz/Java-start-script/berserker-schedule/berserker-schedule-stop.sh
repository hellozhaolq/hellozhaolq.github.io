PID=$(ps -ef | grep berserker-schedule.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-schedule is already stopped
else
  echo kill $PID
  kill $PID
fi

