PID=$(ps -ef | grep berserker-schedule.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-schedule is running
else
  echo kill $PID
  kill $PID
  echo berserker-schedule is already stopped
  echo berserker-schedule is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60181 -jar berserker-schedule.jar >/dev/null 2>berserker-schedule-error-60181.log &
