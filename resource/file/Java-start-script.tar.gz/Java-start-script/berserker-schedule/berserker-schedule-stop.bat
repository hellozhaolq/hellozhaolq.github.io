@echo off
echo ---------------------- berserker-schedule stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-schedule > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-schedule closed successfully
) else (
    echo berserker-schedule is not running
)

del %pidPath%
echo ---------------------- berserker-schedule stop begin ----------------------