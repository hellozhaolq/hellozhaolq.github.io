pwd=$PWD

cd $pwd/berserker-gateway
chmod +x ./berserker-gateway-stop.sh
source ./berserker-gateway-stop.sh

cd $pwd/berserker-auth
chmod +x ./berserker-auth-stop.sh
source ./berserker-auth-stop.sh

cd $pwd/berserker-base
chmod +x ./berserker-base-stop.sh
source ./berserker-base-stop.sh

cd $pwd/berserker-app
chmod +x ./berserker-app-stop.sh
source ./berserker-app-stop.sh

cd $pwd/berserker-advertising
chmod +x ./berserker-advertising-stop.sh
source ./berserker-advertising-stop.sh

cd $pwd/berserker-ykt
chmod +x ./berserker-ykt-stop.sh
source ./berserker-ykt-stop.sh

cd $pwd/berserker-ykt-sync
chmod +x ./berserker-ykt-sync-stop.sh
source ./berserker-ykt-sync-stop.sh

cd $pwd/berserker-ykt-turnover
chmod +x ./berserker-ykt-turnover-stop.sh
source ./berserker-ykt-turnover-stop.sh

cd $pwd/berserker-search
chmod +x ./berserker-search-stop.sh
source ./berserker-search-stop.sh

cd $pwd/berserker-secure
chmod +x ./berserker-secure-stop.sh
source ./berserker-secure-stop.sh

cd $pwd/berserker-schedule
chmod +x ./berserker-schedule-stop.sh
source ./berserker-schedule-stop.sh

cd $pwd/berserker-log
chmod +x ./berserker-log-stop.sh
source ./berserker-log-stop.sh

cd $pwd/berserker-message
chmod +x ./berserker-message-stop.sh
source ./berserker-message-stop.sh





cd $pwd/blade-gateway
chmod +x ./blade-gateway-stop.sh
source ./blade-gateway-stop.sh

cd $pwd/blade-auth
chmod +x ./blade-auth-stop.sh
source ./blade-auth-stop.sh

cd $pwd/blade-manage
chmod +x ./blade-manage-stop.sh
source ./blade-manage-stop.sh

cd $pwd/blade-charge
chmod +x ./blade-charge-stop.sh
source ./blade-charge-stop.sh

cd $pwd/blade-pay
chmod +x ./blade-pay-stop.sh
source ./blade-pay-stop.sh



# 跳过旧版stop，否则它会stop掉本机所有的java项目
if [ 1 == 2 ]
then
	PID=$(ps -ef | grep java | grep -v grep | awk '{ print $2 }')
	if [ -z "$PID" ]
	then
	  echo 'java program is not running'
	else
	  echo kill $PID
	  kill $PID
	fi
fi



