@echo off
echo ---------------------- berserker-base start begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-base > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-base closed successfully
)
echo Preparing to run the berserker-base program, please wait 3 seconds...
choice /t 3 /d y /n >nul
rem TIMEOUT /t 5 /nobreak > NUL
rem TIMEOUT /t 3 /nobreak


echo berserker-base is running

start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-base.jar --server.port=60041
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-base.jar --server.port=60042
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-base.jar --server.port=60043
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-base.jar --server.port=60044
start javaw -server -jar -Dfile.encoding=UTF-8 -Xms1024M ./berserker-base.jar --server.port=60045

del %pidPath%
echo ---------------------- berserker-base start end ----------------------