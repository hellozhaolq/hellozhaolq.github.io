@echo off
rem set JAVA_HOME=G:\syntong\jdk1.8.0_112
rem set PATH=%JAVA_HOME%\bin;
java -server -jar -Dfile.encoding=utf-8 -Xms1024M ./berserker-base.jar  --server.port=60041
pause