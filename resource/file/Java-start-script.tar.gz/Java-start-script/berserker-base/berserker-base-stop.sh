PID=$(ps -ef | grep berserker-base.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-base is already stopped
else
  echo kill $PID
  kill $PID
fi

