@echo off
echo ---------------------- berserker-base stop begin ----------------------
set pidFile=pid
set pidPath=%CD%\%pidFile%
jps -l -m | findstr berserker-base > %pidPath%
FOR %%I IN (%pidPath%) DO SET FileSize=%%~zI
if %FileSize% neq 0 (
    for /f "tokens=1" %%i in (%pidPath%) do (
        taskkill /f /pid %%i
    )
	echo berserker-base closed successfully
) else (
    echo berserker-base is not running
)

del %pidPath%
echo ---------------------- berserker-base stop begin ----------------------