PID=$(ps -ef | grep berserker-base.jar | grep -v grep | awk '{ print $2 }')
if [ -z "$PID" ]
then
  echo berserker-base is running
else
  echo kill $PID
  kill $PID
  echo berserker-base is already stopped
  echo berserker-base is running
fi


nohup java -Dfile.encoding=UTF-8 -Dserver.port=60041 -jar berserker-base.jar >/dev/null 2>berserker-base-error-60041.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60042 -jar berserker-base.jar >/dev/null 2>berserker-base-error-60042.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60043 -jar berserker-base.jar >/dev/null 2>berserker-base-error-60043.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60044 -jar berserker-base.jar >/dev/null 2>berserker-base-error-60044.log &
nohup java -Dfile.encoding=UTF-8 -Dserver.port=60045 -jar berserker-base.jar >/dev/null 2>berserker-base-error-60045.log &
